package com.example.projet_android;

import java.util.ArrayList;

public class Fields {
    String type_prise;
    ArrayList<Double> coord = new ArrayList<>();
    String nom_dep;
    Double puiss_max;
    String commune;
    int dep_code;
    String n_station;
    String acces_recharge;
    String ad_station;
    String accessibilte;

    public Fields(String type_prise, ArrayList<Double> coord, String nom_dep, Double puiss_max, String commune, int dep_code, String n_station, String acces_recharge, String ad_station, String accessibilte) {
        this.type_prise = type_prise;
        this.coord = coord;
        this.nom_dep = nom_dep;
        this.puiss_max = puiss_max;
        this.commune = commune;
        this.dep_code = dep_code;
        this.n_station = n_station;
        this.acces_recharge = acces_recharge;
        this.ad_station = ad_station;
        this.accessibilte = accessibilte;
    }

    public String getType_prise() {
        return type_prise;
    }

    public ArrayList<Double> getCoord() {
        return coord;
    }

    public String getNom_dep() {
        return nom_dep;
    }

    public Double getPuiss_max() {
        return puiss_max;
    }

    public String getCommune() {
        return commune;
    }

    public int getDep_code() {
        return dep_code;
    }

    public String getN_station() {
        return n_station;
    }

    public String getAcces_recharge() {
        return acces_recharge;
    }

    public String getAd_station() {
        return ad_station;
    }

    public String getAccessibilte() {
        return accessibilte;
    }
}
