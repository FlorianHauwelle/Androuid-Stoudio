package com.example.projet_android;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Api {

        String BASE_URL = "https://public.opendatasoft.com/api/records/1.0/search/";
        @GET("?dataset=fichier-consolide-des-bornes-de-recharge-pour-vehicules-electriques-irve&q=&facet=n_enseigne&facet=nbre_pdc&facet=puiss_max&facet=accessibilite&facet=nom_epci&facet=commune&facet=nom_reg&facet=nom_dep")
        Call<Records> getBorneElectrique();
    }
