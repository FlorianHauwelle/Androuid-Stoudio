package com.example.projet_android;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ListView;
import android.widget.Toast;

import java.io.Serializable;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Splash extends AppCompatActivity {
    private static int SPLASH_TIME_OUT = 2000;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);
        getSupportActionBar().hide();


        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                Intent homeIntent = new Intent(Splash.this, MainActivity.class);
                homeIntent.putExtra("apiData", (Serializable) getBorneElectrique());
                startActivity(homeIntent);
                finish();
            }
        }, SPLASH_TIME_OUT);

    }

    public Records getBorneElectrique() {
        Records data = null;
        Call<Records> call = RetrofitClient.getInstance().getMyApi().getBorneElectrique();
        call.enqueue(new Callback<Records>() {

            @Override
            public void onResponse(Call<Records> call, Response<Records> response) {
                if(response.isSuccessful() && response.body() != null){
                    Records data = response.body();
                }
            }
            @Override
            public void onFailure(Call<Records> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "An error has occured", Toast.LENGTH_LONG).show();
            }

        }); return data;
    }
}