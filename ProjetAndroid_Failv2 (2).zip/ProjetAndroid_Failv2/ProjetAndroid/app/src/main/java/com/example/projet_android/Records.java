package com.example.projet_android;

import com.example.projet_android.BorneElectrique;

import java.util.ArrayList;

public class Records {

    ArrayList<BorneElectrique> records = new ArrayList<BorneElectrique>();

    public Records(ArrayList<BorneElectrique> records) {
        this.records = records;
    }

    public ArrayList<BorneElectrique> getRecords() {
        return records;
    }
}
