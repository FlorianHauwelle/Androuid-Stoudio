package com.example.projet_android;

import java.util.ArrayList;

public class Fields {
    ArrayList<Double> coord = new ArrayList<>();
    String nom_dep;
    String commune;
    int dep_code;
    String n_station;
    String acces_recharge;
    String ad_station;
    String accessibilite;

    public Fields(ArrayList<Double> coord, String nom_dep, String commune, int dep_code, String n_station, String acces_recharge, String ad_station, String accessibilite) {
        this.coord = coord;
        this.nom_dep = nom_dep;
        this.commune = commune;
        this.dep_code = dep_code;
        this.n_station = n_station;
        this.acces_recharge = acces_recharge;
        this.ad_station = ad_station;
        this.accessibilite = accessibilite;
    }

    public ArrayList<Double> getCoord() {
        return coord;
    }

    public String getNom_dep() {
        return nom_dep;
    }

    public String getCommune() {
        return commune;
    }

    public int getDep_code() {
        return dep_code;
    }

    public String getN_station() {
        return n_station;
    }

    public String getAcces_recharge() {
        return acces_recharge;
    }

    public String getAd_station() {
        return ad_station;
    }

    public String getAccessibilite() {
        return accessibilite;
    }
}
