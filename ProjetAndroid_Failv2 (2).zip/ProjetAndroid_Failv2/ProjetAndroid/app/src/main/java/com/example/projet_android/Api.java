package com.example.projet_android;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Api {

        String BASE_URL = "https://public.opendatasoft.com/api/records/1.0/search/";
        @GET("?dataset=fichier-consolide-des-bornes-de-recharge-pour-vehicules-electriques-irve&q=&rows=50&facet=n_station&facet=ad_station&facet=commune&facet=dep_code&facet=accessibilite&facet=acces_recharge&facet=puiss_max")
        Call<Records> getBorneElectrique();
    }
