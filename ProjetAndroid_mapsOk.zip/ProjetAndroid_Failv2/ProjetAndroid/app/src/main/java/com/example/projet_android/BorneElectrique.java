package com.example.projet_android;

import java.io.Serializable;

public class BorneElectrique implements Serializable {
    private Fields fields;

    public BorneElectrique(Fields fields) {
        this.fields = fields;
    }

    public Fields getFields() {
        return fields;
    }
}
