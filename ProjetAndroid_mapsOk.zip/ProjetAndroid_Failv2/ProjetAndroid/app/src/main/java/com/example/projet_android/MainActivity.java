package com.example.projet_android;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ProgressBar progressBar;
    LinearLayoutManager layoutManager;
    BornesAdapter adapter;
    ArrayList<BorneElectrique> borneList = new ArrayList<>();
    Button btMaps;
    Records records;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        recyclerView = findViewById(R.id.recyclerView);
        btMaps = findViewById(R.id.btMaps);

        layoutManager = new LinearLayoutManager(this);
        adapter = new BornesAdapter(borneList);
        progressBar = findViewById(R.id.progressBar);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
        getRecords();

        btMaps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent homeIntent = new Intent(MainActivity.this, MapsActivity.class);
                homeIntent.putExtra("apiData", (Serializable) records);
                startActivity(homeIntent);
            }
        });
    }

    private void getRecords() {
        progressBar.setVisibility(View.VISIBLE);
        Call<Records> call = RetrofitClient.getInstance().getMyApi().getBorneElectrique();
        call.enqueue(new Callback<Records>() {

            @Override
            public void onResponse(Call<Records> call, Response<Records> response) {
                if(response.isSuccessful() && response.body() != null){
                    records = response.body();
                    borneList.addAll(records.getRecords());
                    adapter.notifyDataSetChanged();
                    progressBar.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(Call<Records> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), "Vérifier votre connexion internet", Toast.LENGTH_LONG).show();
            }

        });
    }

}