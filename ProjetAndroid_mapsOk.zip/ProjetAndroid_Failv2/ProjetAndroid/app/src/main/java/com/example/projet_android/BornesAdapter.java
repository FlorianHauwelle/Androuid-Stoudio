package com.example.projet_android;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class BornesAdapter extends RecyclerView.Adapter<BornesAdapter.ViewHolder> {

    private ArrayList<BorneElectrique> borneList;

    public BornesAdapter(ArrayList<BorneElectrique> borneList) {
        this.borneList = borneList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.tvAdresseStation.setText(borneList.get(position).getFields().getAd_station());
        holder.tvAccessibilite.setText(borneList.get(position).getFields().getAccessibilite());
        holder.tvRecharge.setText(borneList.get(position).getFields().getAcces_recharge());

    }

    @Override
    public int getItemCount() {
        return borneList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvAdresseStation;
        TextView tvAccessibilite;
        TextView tvRecharge;
        ImageView ivBorne;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvAdresseStation = itemView.findViewById(R.id.tvAdresseStation);
            tvAccessibilite = itemView.findViewById(R.id.tvAccessibilite);
            tvRecharge = itemView.findViewById(R.id.tvRecharge);
            ivBorne = itemView.findViewById(R.id.ivBorne);

        }
    }
}
