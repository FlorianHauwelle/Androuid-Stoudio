package com.example.projet_android;

public class BorneElectrique {
    private Fields fields;
}
