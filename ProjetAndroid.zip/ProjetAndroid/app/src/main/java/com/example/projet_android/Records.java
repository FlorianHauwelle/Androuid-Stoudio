package com.example.projet_android;

import com.example.projet_android.BorneElectrique;

import java.util.ArrayList;

public class Records {

    ArrayList<BorneElectrique> borneElectrique = new ArrayList<BorneElectrique>();

    public Records(ArrayList<BorneElectrique> borneElectrique) {
        this.borneElectrique = borneElectrique;
    }

    public ArrayList<BorneElectrique> getBorneElectrique() {
        return borneElectrique;
    }
}
