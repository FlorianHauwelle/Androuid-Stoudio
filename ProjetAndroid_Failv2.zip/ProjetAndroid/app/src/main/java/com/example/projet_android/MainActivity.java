package com.example.projet_android;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ProgressBar progressBar;
    LinearLayoutManager layoutManager;
    BornesAdapter adapter;
    List<BorneElectrique> borneList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        recyclerView = findViewById(R.id.recyclerView);
        progressBar = findViewById(R.id.progressBar);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new BornesAdapter(borneList);
        recyclerView.setAdapter(adapter);

        fetchBornes();

        //BornesAdapter adapter = new BornesAdapter((List<BorneElectrique>) getIntent().getSerializableExtra("apiData"));
    }

    private void fetchBornes() {
        progressBar.setVisibility(View.VISIBLE);
        Call<Records> call = RetrofitClient.getInstance().getMyApi().getBorneElectrique();
        call.enqueue(new Callback<Records>() {

            @Override
            public void onResponse(Call<Records> call, Response<Records> response) {
                if(response.isSuccessful() && response.body() != null){
                    borneList.addAll((Collection<? extends BorneElectrique>) response.body());
                    adapter.notifyDataSetChanged();
                    progressBar.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(Call<Records> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), "An error has occured", Toast.LENGTH_LONG).show();
            }

        });
    }

}