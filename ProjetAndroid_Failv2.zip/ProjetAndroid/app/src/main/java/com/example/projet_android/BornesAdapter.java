package com.example.projet_android;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.lang.reflect.Field;
import java.util.List;

public class BornesAdapter extends RecyclerView.Adapter<BornesAdapter.ViewHolder> {

    private List<BorneElectrique> borneList;

    public BornesAdapter(List<BorneElectrique> borneList) {
        this.borneList = borneList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.tvNomStation.setText(borneList.get(position).getFields().getN_station());
        holder.tvAdresseStation.setText(borneList.get(position).getFields().getAd_station());
    }

    @Override
    public int getItemCount() {
        return borneList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvNomStation;
        TextView tvAdresseStation;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvNomStation = itemView.findViewById(R.id.tvNomStation);
            tvAdresseStation = itemView.findViewById(R.id.tvAdresseStation);
        }
    }
}
